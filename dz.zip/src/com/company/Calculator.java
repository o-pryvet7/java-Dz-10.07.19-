package com.company;

import java.util.Scanner;

public class Calculator {
	
	private Scanner scanner = new Scanner(System.in);
	private int[] Numbers = new int[2];
	private char Operation;
	private Exception gotoInputOperation;
	
	private Calculator() {
		this.Operation = '+';
		this.Numbers[0] = 0;
		this.Numbers[1] = this.Numbers[0];
	}
	
	public static void Start() {
		Calculator calculator = new Calculator();
		calculator.Input();
		calculator.Implementation(calculator.getNumber1(), calculator.getOperation(), calculator.getNumber2());
		calculator.Print();
		System.out.println("\n\n");
		Calculator.Start();
	}
	
	private int getNumber1() {
		return this.Numbers[0];
	}
	
	private int getNumber2() {
		return this.Numbers[1];
	}
	
	private char getOperation() {
		return this.Operation;
	}
	
	private void setOperation(char Operation_) {
		this.Operation = Operation_;
	}
	
	private void setNumbers(int Num1,int Num2) {
		this.Numbers[0] = Num1;
		this.Numbers[1] = Num2;
	}
	
	private void Input() {
		int TempOperation = 0;
		int TempNum1 = 0;
		int TempNum2 = 0;
		System.out.println("Input 1st number");
		while (!scanner.hasNextInt()){
			System.out.println("ERROR. TRY AGAIN");
			scanner.next();
		}
		TempNum1 = scanner.nextInt();
		
		while(!((TempOperation >=1) && (TempOperation <=5))){
			System.out.println("Input Operation [+(1), -(2), *(3), /(4), ^(5) (power)]");
			while(!scanner.hasNextInt()){
				System.out.println("ERROR. TRY AGAIN");
				scanner.next();
			}
			TempOperation = scanner.nextInt();
			
			switch (TempOperation) {
			case 1:
				Operation = '+';
				break;
			case 2:
				Operation = '-';
				break;
			case 3:
				Operation = '*';
				break;
			case 4:
				Operation = '/';
				break;
			case 5:
				Operation = '^';
				break;
			default:
				System.out.println("Is not [+,-,*,/,^]. ERROR. TRY AGAIN");

				break;
			}
		}
		
		setOperation(Operation);
		
		System.out.println("Input 2nd number");
		while (!scanner.hasNextInt()){
			System.out.println("ERROR. TRY AGAIN");
			scanner.next();
		}
		TempNum2 = scanner.nextInt();
		setNumbers(TempNum1, TempNum2);
		System.out.println();
	}
	
	private void Print() {
		System.out.println("RESULT: ");
		System.out.println(getNumber1()+" "+getOperation()+" "+getNumber2()+" = "+
					Implementation(getNumber1(),getOperation(),getNumber2()) );
	}
	
	private int Implementation(int Number1,char Operation,int Number2) {
		int TempResult = 0;
		switch (Operation) {
		case '+':
			TempResult = Number1 + Number2;
			break;
		case '-':
			TempResult = Number1 - Number2;
			break;
		case '*':
			TempResult = Number1 * Number2;
			break;
		case '/':
			TempResult = Number1 / Number2;
			break;
		case '^':
			TempResult = power(Number1,Number2);
			break;
		default:
			System.out.println("ERROR");
			break;
		}		
		return TempResult;
	}
	
	private int power(int Number, int power_) {
		if(power_ <= 0)
			return 1;
		else if(power_ == 1)
			return Number;
		else
			return Number * (power(Number,power_-1));
	}
	
}
